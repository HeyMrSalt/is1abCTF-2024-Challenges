import random
import os
from Crypto.Util.number import getPrime, inverse, long_to_bytes, bytes_to_long

file_path = 'flag.txt'

def load_flag_from_file(filename):
    if not os.path.isfile(filename):
        raise FileNotFoundError(f"The file '{filename}' does not exist.")
    
    with open(filename, 'r') as file:
        content = file.read().strip()
        content = content.replace('\n', '').replace('\r', '')
        return content

def generate_keypair():
    p = getPrime(73)
    q = getPrime(73)
    
    while p == q:
        q = getPrime(73)

    n = p * q
    phi = (p - 1) * (q - 1)
    
    e = random.randrange(2, phi)
    g = gcd(e, phi)
    while g != 1:
        e = random.randrange(2, phi)
        g = gcd(e, phi)
    
    d = inverse(e, phi)
    
    return ((e, n), (d, n))

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def encrypt(public_key, plaintext):
    e, n = public_key
    plaintext_bytes = plaintext.encode('utf-8')
    plaintext_long = bytes_to_long(plaintext_bytes)
    
    if plaintext_long >= n:
        raise ValueError("Plaintext too large for the key size.")
    
    encrypted_long = pow(plaintext_long, e, n)
    return encrypted_long

def decrypt(private_key, encrypted_message):
    d, n = private_key
    decrypted_long = pow(encrypted_message, d, n)
    decrypted_bytes = long_to_bytes(decrypted_long)
    try:
        decrypted_message = decrypted_bytes.decode('utf-8')
    except UnicodeDecodeError:
        decrypted_message = None
    return decrypted_message

public_key, private_key = generate_keypair()

plaintext = load_flag_from_file(file_path)
encrypted_message = encrypt(public_key, plaintext)
decrypted_message = decrypt(private_key, encrypted_message)

print("Public Key:", public_key)
print("Encrypted Message:", encrypted_message)
print("Decrypted Message:", decrypted_message)
